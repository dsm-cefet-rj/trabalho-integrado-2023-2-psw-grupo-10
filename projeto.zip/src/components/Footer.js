import React from "react";

class Footer extends React.Component {
    render() {
        return (
            <footer>
                <div className="col-100 footer">
                    <div className="content">
                        <div className="col-4">
                            <h3><b>Experiências</b></h3>
                            <p>Amei o serviço - Fulana de Tal</p>
                            <p className="clock">09 de agosto de 2023</p>
                            <p>Eles sabem o que fazem - Beltrano da Silva</p>
                            <p className="clock">1º de novembro de 2023</p>
                        </div>
                        <div className="col-4">
                            <h3><b>Tags</b></h3>
                            <p style={{fontFamily: "monospace"}}>reforma refrigeracao pintura servicos</p>
                        </div>
                        <div className="col-4">
                            <h3><b>Um pouco sobre nós</b></h3>
                            <p>
                                Fazemos excelentes serviços de reforma
                            </p>
                        </div>
                        <div className="col-4">
                            <h3><b>Entre em contato!</b></h3>
                            <p>
                                Fique a vontade de pedir um orçamento!
                            </p>
                            <p className="local">Rio de Janeiro / RJ</p>
                            <p className="emailico">contato@reforme.ja</p>
                            <p className="telefoneico">(21) 99999-0000</p>
                        </div>
                    </div>
                </div>
            
                <div className="col-100 footer-2">
          <div className="content">
            <p>
              There are many variations of passages of Lorem Ipsum available, but the majority have suffered
            </p>
          </div>
        </div>
            
            </footer>
        
        );
    }
}

export default Footer;
