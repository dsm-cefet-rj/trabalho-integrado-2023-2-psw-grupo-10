import React from "react";
import logoImage from "../img/logo.png";
import rssImage from "../img/rss.png";
import facebookImage from "../img/face.png";
import twitterImage from "../img/tw.png";
import linkedinImage from "../img/linkedin.png";

import { NavLink } from 'react-router-dom';

const socialNetworks = [
    {
        name: "Facebook",
        image: facebookImage,
        link: "https://facebook.com"
    },
    {
        name: "LinkedIn",
        image: linkedinImage,
        link: "https://linkedin.com"
    },
    {
        name: "Twitter",
        image: twitterImage,
        link: "https://facebook.com"
    },
    {
        name: "RSS",
        image: rssImage,
        link: "https://example.com"
    },
];

const navigation = [
    {
        name: "Página Inicial",
        link: "/Home",
        state: "active"
    },
    {
        name: "Sobre nós",
        link: "/About-Us",
        state: "active"
    },
    {
        name: "Serviços",
        link: "/Service",
        state: "active"
    },
    {
        name: "Contacte-nos",
        link: "/Contact-Us",
        state: "active"
    },
];


class Header extends React.Component {
    render() {
        return (
            <div>
                <header className="menu-principal">
                    <div className="header-1">
                        <div className="logo">
                            <h1>REFORMA JÁ!</h1>
                        </div>
                        <div className="redes-sociais">
                            <ul>
                                {socialNetworks.map((network, _) => (
                                    <li>
                                        <a href={network.link}>
                                            <img src={network.image} alt={`${network.title} Icon`} />
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                </header>
                <nav className="menu-urls">
                    <div className="header-2">
                        <div className="menu">
                            <ul>
                                {navigation.map((nav, _) => (
                                    <li>
                                        <NavLink to={nav.link} activeClassName={nav.state}>
                                            {nav.name}
                                        </NavLink>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div className="busca">
                            <input
                                placeholder="Search Something"
                                type="text" />

                            {/* <button onClick={this.handleSearch}>Search</button>*/}
                        </div>
                    </div>
                </nav>
            </div>
        );
    }
}

export default Header;
