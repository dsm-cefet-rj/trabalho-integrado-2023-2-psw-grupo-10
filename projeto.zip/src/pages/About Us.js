import React from "react";
import { useNavigate } from "react-router-dom";
import aboutImage from "../img/sobre-nos.png"; // Import your image

function AboutUs() {
  const navigate = useNavigate();

  const goToHomePage = () => {
    navigate("/Home");
  };

  return (
    <div>
      <main>
        <h1>Sobre nós</h1>
        <p>
          Trabalhamos com reformas de estabelecimentos, serviços de pintura, e serviços de refrigeração.
          Seja capaz de receber seus clientes em um ambiente acolhedor. Espaço também é vendas!
        </p>
        <img style={{width: "100%"}} src={aboutImage} alt="Sobre nós" />
      </main>
    </div>
  );
}

export default AboutUs;

