import React from "react";
import { Link } from 'react-router-dom';

import bannerImage1 from "../img/banner1.jpeg";
import bannerImage2 from "../img/banner2.jpeg";
import contentImage from "../img/content-1.png";
import contentImage2 from "../img/content-2.png";
import contentImage3 from "../img/content-3.png";
import imagem1 from "../img/imagem1.png";
import imagem2 from "../img/imagem2.png";
import imagem3 from "../img/imagem3.png";
import logo1 from "../img/logo1.png"; 
import logo2 from "../img/logo2.png"; 
import logo3 from "../img/logo3.png"; 
import logo4 from "../img/logo4.png";

const banners = [
  bannerImage1,
//  bannerImage2,
];

const logos = [
  logo1,
  logo2,
  logo3,
  logo4,
];

class Home extends React.Component {

  



  render() {
    return (
      <div>
        {/* Additional content starts here */}
        <div class="col-100">
          <div className="slider-principal">
            {banners.map((banner, _) => (
              <img src={banner} alt="Banner" />
            )
            )}
          </div>
        </div>
        <div class="col-100">
          <div class="content texto-destaque">
            <h1>
              Serviços de reforma
            </h1>
            <p style={{fontSize: "larger"}}>
              Oferecemos excelentes serviços de reformas para sua empresa!
              Entre em contato conosco <Link to="/Contact-Us">aqui</Link>
            </p>
          </div>
        </div>
        <div class="col-100 bloco-logos">
          <div class="content">
            {logos.map((logo, _) => (
              <div class="col-4">
              <img
                alt="logo"
                title="logo"
                src={logo}
              />
            </div>
            )
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default Home;


