import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

import reforma from '../img/reformas.png';
import pintura from '../img/pintura.png';
import refrigeracao from '../img/refrigeracao.png';

function Service() {
  const navigate = useNavigate();
  const [selectedImage, setSelectedImage] = useState(null); // State to store selected image

  // Define image information including price
  const imageInfo = [
    {
      src: reforma,
      title: 'REFORMAS',
      description: 'Oferecemos os serviços de reforma completa das instalações da sua empresa.',
      price: 'A partir de R$ 500 por m²',
    },
    {
      src: pintura,
      title: 'PINTURA',
      description: 'Oferecemos serviço de pintura, podendo realizar um design moderno para seu estabelecimento.',
      price: 'A partir de R$100 a parede.', // Add a price field
    },
    {
      src: refrigeracao,
      title: 'REFRIGERAÇÃO',
      description: 'Também realizamos serviços de refrigeração, instalação e manutenção de ar-condicionados.',
      price: 'A partir de R$ 300 a manutenção', // Add a price field
    },
  ];

  // Function to handle image click and display details
  const handleImageClick = (image) => {
    setSelectedImage(image);
  };

  // Function to navigate to the Home page when the button is clicked
  const handleButtonClick = () => {
    navigate('/Home');
  };

  return (
    <div>
        <div className="content" style={{ marginLeft: "24%", float: "left" }}>
          {imageInfo.map((image, index) => (
            <div className="col-3 bloco-texto bloco-imagem" key={index}>
              <Link to="#" onClick={() => handleImageClick(image)}>
                <img src={image.src} alt={image.title} />
              </Link>
              <p>
                <b>{image.title}</b>
              </p>
            </div>
          ))}
        </div>
      {selectedImage && (
        <div class="bloco-imagens-texto">
          <h2>Serviço de {selectedImage.title}</h2>
          <p>{selectedImage.description}</p>
          <p class="preco">{selectedImage.price}</p>
        </div>
      )}
    </div>
  );
}

export default Service;

